import geopandas as gpd
import numpy as np
import math
from shapely.geometry import Polygon, LineString, Point, MultiPolygon
from shapely.ops import unary_union, split
from shapely.affinity import rotate, translate, scale
import ezdxf
from typing import List, Tuple, Optional, Dict, Any
import random

class LoteamentoProcessorUltraAvancado:
    """
    Processador ultra-avançado de loteamento urbano com:
    - Subdivisão otimizada de lotes irregulares
    - Distribuição inteligente dentro das quadras
    - Liberdade criativa total na formação de quadras
    - Otimização de lotes de esquina
    """
    
    def __init__(self, parametros: dict):
        self.parametros = parametros
        self.perimetro_original = None
        self.perimetro_internalizado = None
        self.malha_viaria = []
        self.ruas = []
        self.calcadas = []
        self.quadras = []
        self.lotes = []
        self.areas_verdes = []
        self.areas_institucionais = []
        
        # NOVAS VARIÁVEIS - Plano de Desenvolvimento 2.0
        self.topografia_map = None  # Mapa de declividade
        self.lotes_esquina = []     # Lotes de esquina identificados
        self.lotes_atipicos = []    # Lotes atípicos
        self.ruas_principais = []   # Ruas principais
        self.ruas_secundarias = []  # Ruas secundárias
        self.malhas_hipoteses = []  # Múltiplas hipóteses de malha viária
        self.pontuacoes_hipoteses = []  # Pontuações das hipóteses
        
        # Configurações avançadas baseadas nos parâmetros
        self.configurar_estrategias_avancadas()
    
    def configurar_estrategias_avancadas(self):
        """
        Configura estratégias avançadas baseadas nos parâmetros do usuário.
        """
        # Configurar tolerância de forma
        tolerancia = self.parametros.get('tolerancia_forma', 'Alta (Mais Irregular)')
        if 'Baixa' in tolerancia:
            self.fator_irregularidade = 0.2
        elif 'Média' in tolerancia:
            self.fator_irregularidade = 0.5
        else:  # Alta
            self.fator_irregularidade = 0.8
        
        # Configurar liberdade criativa
        liberdade = self.parametros.get('liberdade_criativa', 'Máxima')
        if liberdade == 'Conservadora':
            self.fator_criatividade = 0.2
        elif liberdade == 'Moderada':
            self.fator_criatividade = 0.4
        elif liberdade == 'Criativa':
            self.fator_criatividade = 0.7
        else:  # Máxima
            self.fator_criatividade = 1.0
        
        # Configurar densidade
        densidade = self.parametros.get('densidade_lotes', 'Alta')
        if densidade == 'Baixa':
            self.fator_densidade = 0.6
        elif densidade == 'Média':
            self.fator_densidade = 0.8
        elif densidade == 'Alta':
            self.fator_densidade = 1.0
        else:  # Máxima
            self.fator_densidade = 1.3
    
    def carregar_perimetro(self, arquivo_path: str) -> bool:
        """
        Carrega o perímetro do arquivo DXF ou KML.
        """
        try:
            print(f"Carregando arquivo: {arquivo_path}")
            
            if arquivo_path.lower().endswith('.dxf'):
                return self._carregar_dxf(arquivo_path)
            elif arquivo_path.lower().endswith('.kml'):
                return self._carregar_kml(arquivo_path)
            else:
                print("Formato de arquivo não suportado")
                return False
                
        except Exception as e:
            print(f"Erro ao carregar perímetro: {e}")
            return False
    
    def _carregar_dxf(self, arquivo_path: str) -> bool:
        """Carrega perímetro de arquivo DXF"""
        try:
            doc = ezdxf.readfile(arquivo_path)
            msp = doc.modelspace()
            
            pontos = []
            for entity in msp:
                if entity.dxftype() == 'LWPOLYLINE':
                    pontos = [(p[0], p[1]) for p in entity.get_points()]
                    break
                elif entity.dxftype() == 'POLYLINE':
                    pontos = [(v.dxf.location[0], v.dxf.location[1]) for v in entity.vertices]
                    break
            
            if len(pontos) >= 3:
                if pontos[0] != pontos[-1]:
                    pontos.append(pontos[0])
                
                self.perimetro_original = Polygon(pontos)
                print(f"Perímetro carregado. Área: {self.perimetro_original.area:.2f} m²")
                return True
            
            return False
            
        except Exception as e:
            print(f"Erro ao carregar DXF: {e}")
            return False
    
    def _carregar_kml(self, arquivo_path: str) -> bool:
        """Carrega perímetro de arquivo KML"""
        try:
            gdf = gpd.read_file(arquivo_path)
            if not gdf.empty:
                geometry = gdf.geometry.iloc[0]
                if isinstance(geometry, Polygon):
                    self.perimetro_original = geometry
                    print(f"Perímetro carregado. Área: {self.perimetro_original.area:.2f} m²")
                    return True
            return False
        except Exception as e:
            print(f"Erro ao carregar KML: {e}")
            return False
    
    def processar_loteamento_ultra_avancado(self, arquivo_entrada: str, arquivo_saida: str) -> Dict[str, Any]:
        """
        Executa o processamento ultra-avançado completo com as melhorias do Plano 2.0.
        """
        try:
            print("=== PROCESSAMENTO ULTRA-AVANÇADO DE LOTEAMENTO ===")
            
            # 1. Carregar perímetro
            print("1. Carregando perímetro...")
            if not self.carregar_perimetro(arquivo_entrada):
                return {'sucesso': False, 'erro': 'Erro ao carregar perímetro'}
            
            # 1.5. NOVA FUNCIONALIDADE: Pré-Análise Topográfica
            topografia_path = self.parametros.get('topografia_path')
            if topografia_path:
                print("1.5. Executando pré-análise topográfica...")
                self._pre_analise_topografica(topografia_path)
            
            # 2. Internalizar com calçadas
            print("2. Internalizando perímetro com calçadas...")
            self.internalizar_perimetro_com_calcadas()
            
            # 3. MODIFICADO: Criar sistema viário com múltiplas hipóteses e pontuação
            print("3. Criando sistema viário com análise de hipóteses...")
            self.criar_sistema_viario_com_hipoteses()
            
            # 4. MODIFICADO: Formar quadras com passo de limpeza
            print("4. Formando quadras com refinamento...")
            self.formar_quadras_com_refinamento()
            
            # 5. MODIFICADO: Subdividir com lógica de canto e validação iterativa
            print("5. Subdividindo com otimização avançada...")
            self.subdividir_quadras_ultra_otimizado()
            
            # 6. MODIFICADO: Alocar áreas comuns estrategicamente
            print("6. Alocando áreas comuns estrategicamente...")
            self.alocar_areas_comuns_estrategicamente()
            
            # 7. MODIFICADO: Exportar resultado com camadas detalhadas
            print("7. Exportando resultado...")
            self.exportar_dxf_ultra_avancado(arquivo_saida)
            
            # Calcular estatísticas
            estatisticas = self.calcular_estatisticas_detalhadas()
            
            print("=== PROCESSAMENTO CONCLUÍDO ===")
            
            return {
                'sucesso': True,
                **estatisticas
            }
            
        except Exception as e:
            print(f"Erro no processamento: {e}")
            return {'sucesso': False, 'erro': str(e)}
    
    def internalizar_perimetro_com_calcadas(self):
        """
        Internaliza o perímetro considerando calçadas.
        """
        try:
            largura_calcada = self.parametros['largura_calcada']
            offset_distance = largura_calcada + 1.0  # Margem adicional
            
            perimetro_internalizado = self.perimetro_original.buffer(-offset_distance)
            
            if isinstance(perimetro_internalizado, Polygon) and not perimetro_internalizado.is_empty:
                self.perimetro_internalizado = perimetro_internalizado
            else:
                # Se o buffer negativo falhar, usar 80% do perímetro original
                centroid = self.perimetro_original.centroid
                self.perimetro_internalizado = scale(self.perimetro_original, xfact=0.8, yfact=0.8, origin=centroid)
            
            print(f"Perímetro internalizado. Área: {self.perimetro_internalizado.area:.2f} m²")
            
        except Exception as e:
            print(f"Erro na internalização: {e}")
            self.perimetro_internalizado = self.perimetro_original
    
    def _pre_analise_topografica(self, topografia_path: str):
        """
        NOVA FUNCIONALIDADE: Executa pré-análise topográfica para criar mapa de declividade.
        """
        try:
            print(f"Carregando arquivo de topografia: {topografia_path}")
            
            # Carregar DXF de topografia
            doc = ezdxf.readfile(topografia_path)
            msp = doc.modelspace()
            
            # Extrair curvas de nível
            curvas_nivel = []
            for entity in msp:
                if entity.dxftype() in ['LWPOLYLINE', 'POLYLINE', 'LINE']:
                    if hasattr(entity, 'get_points'):
                        pontos = [(p[0], p[1]) for p in entity.get_points()]
                    elif hasattr(entity, 'vertices'):
                        pontos = [(v.dxf.location[0], v.dxf.location[1]) for v in entity.vertices]
                    elif entity.dxftype() == 'LINE':
                        pontos = [(entity.dxf.start[0], entity.dxf.start[1]), 
                                 (entity.dxf.end[0], entity.dxf.end[1])]
                    else:
                        continue
                    
                    if len(pontos) >= 2:
                        curvas_nivel.append(LineString(pontos))
            
            # Criar mapa de declividade simplificado
            self.topografia_map = self._criar_mapa_declividade(curvas_nivel)
            
            print(f"Pré-análise topográfica concluída. {len(curvas_nivel)} curvas de nível processadas.")
            
        except Exception as e:
            print(f"Erro na pré-análise topográfica: {e}")
            self.topografia_map = None
    
    def _criar_mapa_declividade(self, curvas_nivel: List[LineString]) -> Dict[str, Any]:
        """
        Cria um mapa de declividade simplificado baseado nas curvas de nível.
        """
        try:
            if not curvas_nivel:
                return None
            
            # Obter bounds do perímetro
            bounds = self.perimetro_original.bounds
            min_x, min_y, max_x, max_y = bounds
            
            # Criar grade de pontos para análise
            resolucao = 20  # metros
            pontos_x = np.arange(min_x, max_x, resolucao)
            pontos_y = np.arange(min_y, max_y, resolucao)
            
            # Classificar áreas por proximidade às curvas de nível
            areas_alta_declividade = []
            areas_media_declividade = []
            areas_baixa_declividade = []
            
            for x in pontos_x:
                for y in pontos_y:
                    ponto = Point(x, y)
                    if self.perimetro_original.contains(ponto):
                        # Calcular distância mínima às curvas de nível
                        dist_min = min([ponto.distance(curva) for curva in curvas_nivel])
                        
                        if dist_min < 10:  # Próximo às curvas = alta declividade
                            areas_alta_declividade.append(ponto)
                        elif dist_min < 30:  # Distância média = declividade moderada
                            areas_media_declividade.append(ponto)
                        else:  # Longe das curvas = baixa declividade
                            areas_baixa_declividade.append(ponto)
            
            return {
                'curvas_nivel': curvas_nivel,
                'areas_alta_declividade': areas_alta_declividade,
                'areas_media_declividade': areas_media_declividade,
                'areas_baixa_declividade': areas_baixa_declividade
            }
            
        except Exception as e:
            print(f"Erro ao criar mapa de declividade: {e}")
            return None
    
    def criar_sistema_viario_com_hipoteses(self):
        """
        NOVA FUNCIONALIDADE: Cria sistema viário testando múltiplas hipóteses e selecionando a melhor.
        """
        try:
            print("Gerando múltiplas hipóteses de malha viária...")
            
            # Gerar hipóteses
            self.malhas_hipoteses = []
            self.pontuacoes_hipoteses = []
            
            # Hipótese A: Alinhado com o eixo principal do terreno
            print("  Testando Hipótese A: Eixo principal do terreno")
            malha_a = self._gerar_hipotese_eixo_principal()
            pontuacao_a = self._calcular_pontuacao(malha_a)
            self.malhas_hipoteses.append(('Eixo Principal', malha_a))
            self.pontuacoes_hipoteses.append(pontuacao_a)
            
            # Hipótese B: Alinhado com o maior segmento da borda
            print("  Testando Hipótese B: Maior segmento da borda")
            malha_b = self._gerar_hipotese_maior_segmento()
            pontuacao_b = self._calcular_pontuacao(malha_b)
            self.malhas_hipoteses.append(('Maior Segmento', malha_b))
            self.pontuacoes_hipoteses.append(pontuacao_b)
            
            # Hipótese C: Orientação solar
            criterio_orientacao = self.parametros.get('criterio_orientacao_arruamento', 'Otimizar por Eixo Principal')
            if 'Solar' in criterio_orientacao:
                print("  Testando Hipótese C: Orientação solar")
                malha_c = self._gerar_hipotese_orientacao_solar()
                pontuacao_c = self._calcular_pontuacao(malha_c)
                self.malhas_hipoteses.append(('Orientação Solar', malha_c))
                self.pontuacoes_hipoteses.append(pontuacao_c)
            
            # Selecionar a melhor hipótese
            melhor_indice = np.argmax(self.pontuacoes_hipoteses)
            melhor_nome, melhor_malha = self.malhas_hipoteses[melhor_indice]
            melhor_pontuacao = self.pontuacoes_hipoteses[melhor_indice]
            
            print(f"  Melhor hipótese: {melhor_nome} (pontuação: {melhor_pontuacao:.2f})")
            
            # Usar a melhor malha
            self.malha_viaria = melhor_malha
            
            # Gerar ruas e calçadas
            self._gerar_ruas_e_calcadas()
            
            print(f"Sistema viário com hipóteses: {len(self.ruas)} ruas, {len(self.calcadas)} calçadas")
            
        except Exception as e:
            print(f"Erro na criação do sistema viário com hipóteses: {e}")
            # Fallback para método original
            self.criar_sistema_viario_criativo()
    
    def criar_sistema_viario_criativo(self):
        """
        Cria um sistema viário com liberdade criativa baseado nos parâmetros.
        """
        try:
            experimentacao = self.parametros.get('experimentacao_formas', 'Totalmente Livres')
            
            if experimentacao == 'Retangulares':
                self._criar_malha_retangular()
            elif experimentacao == 'Variadas':
                self._criar_malha_variada()
            elif experimentacao == 'Experimentais':
                self._criar_malha_experimental()
            else:  # Totalmente Livres
                self._criar_malha_totalmente_livre()
            
            # Criar ruas e calçadas
            self._gerar_ruas_e_calcadas()
            
            print(f"Sistema viário criativo: {len(self.ruas)} ruas, {len(self.calcadas)} calçadas")
            
        except Exception as e:
            print(f"Erro na criação do sistema viário: {e}")
            self.malha_viaria = []
            self.ruas = []
            self.calcadas = []
    
    def _criar_malha_retangular(self):
        """Cria malha viária retangular tradicional"""
        bounds = self.perimetro_internalizado.bounds
        min_x, min_y, max_x, max_y = bounds
        
        largura_total = max_x - min_x
        altura_total = max_y - min_y
        profundidade_max = self.parametros['profundidade_max_quadra']
        
        linhas_viarias = []
        
        # Linhas verticais
        num_verticais = max(1, int(largura_total / profundidade_max))
        for i in range(1, num_verticais + 1):
            x = min_x + (i * largura_total / (num_verticais + 1))
            linha = LineString([(x, min_y - 10), (x, max_y + 10)])
            intersecao = linha.intersection(self.perimetro_internalizado)
            if isinstance(intersecao, LineString) and intersecao.length > 0:
                linhas_viarias.append(intersecao)
        
        # Linhas horizontais
        num_horizontais = max(1, int(altura_total / profundidade_max))
        for i in range(1, num_horizontais + 1):
            y = min_y + (i * altura_total / (num_horizontais + 1))
            linha = LineString([(min_x - 10, y), (max_x + 10, y)])
            intersecao = linha.intersection(self.perimetro_internalizado)
            if isinstance(intersecao, LineString) and intersecao.length > 0:
                linhas_viarias.append(intersecao)
        
        self.malha_viaria = linhas_viarias
    
    def _criar_malha_variada(self):
        """Cria malha viária com variações"""
        self._criar_malha_retangular()
        
        # Adicionar algumas linhas diagonais
        bounds = self.perimetro_internalizado.bounds
        min_x, min_y, max_x, max_y = bounds
        
        # Diagonal principal
        diagonal = LineString([(min_x, min_y), (max_x, max_y)])
        intersecao = diagonal.intersection(self.perimetro_internalizado)
        if isinstance(intersecao, LineString) and intersecao.length > 0:
            self.malha_viaria.append(intersecao)
    
    def _criar_malha_experimental(self):
        """Cria malha viária experimental"""
        bounds = self.perimetro_internalizado.bounds
        min_x, min_y, max_x, max_y = bounds
        centro_x, centro_y = (min_x + max_x) / 2, (min_y + max_y) / 2
        
        linhas_viarias = []
        
        # Linhas radiais
        num_radiais = 4 + int(self.fator_criatividade * 4)
        for i in range(num_radiais):
            angulo = (2 * math.pi * i) / num_radiais
            raio = max(max_x - min_x, max_y - min_y)
            
            x_fim = centro_x + raio * math.cos(angulo)
            y_fim = centro_y + raio * math.sin(angulo)
            
            linha = LineString([(centro_x, centro_y), (x_fim, y_fim)])
            intersecao = linha.intersection(self.perimetro_internalizado)
            if isinstance(intersecao, LineString) and intersecao.length > 0:
                linhas_viarias.append(intersecao)
        
        # Linhas concêntricas
        num_concentricas = 2 + int(self.fator_criatividade * 2)
        for i in range(1, num_concentricas + 1):
            raio = (i * min(max_x - centro_x, max_y - centro_y)) / (num_concentricas + 1)
            circulo = Point(centro_x, centro_y).buffer(raio).boundary
            intersecao = circulo.intersection(self.perimetro_internalizado)
            if hasattr(intersecao, 'geoms'):
                for geom in intersecao.geoms:
                    if isinstance(geom, LineString) and geom.length > 0:
                        linhas_viarias.append(geom)
            elif isinstance(intersecao, LineString) and intersecao.length > 0:
                linhas_viarias.append(intersecao)
        
        self.malha_viaria = linhas_viarias
    
    def _criar_malha_totalmente_livre(self):
        """Cria malha viária com total liberdade criativa"""
        bounds = self.perimetro_internalizado.bounds
        min_x, min_y, max_x, max_y = bounds
        
        linhas_viarias = []
        
        # Estratégia 1: Linhas orgânicas baseadas na forma do terreno
        coords = list(self.perimetro_internalizado.exterior.coords)
        num_pontos = len(coords)
        
        # Criar linhas conectando pontos opostos
        for i in range(0, num_pontos // 2):
            ponto1 = coords[i]
            ponto2 = coords[i + num_pontos // 2] if i + num_pontos // 2 < num_pontos else coords[i - num_pontos // 2]
            
            linha = LineString([ponto1, ponto2])
            intersecao = linha.intersection(self.perimetro_internalizado)
            if isinstance(intersecao, LineString) and intersecao.length > 0:
                linhas_viarias.append(intersecao)
        
        # Estratégia 2: Linhas baseadas em pontos de interesse
        centroid = self.perimetro_internalizado.centroid
        
        # Encontrar pontos extremos
        pontos_extremos = [
            (min_x, min_y), (max_x, min_y), (max_x, max_y), (min_x, max_y),
            (centroid.x, min_y), (centroid.x, max_y), (min_x, centroid.y), (max_x, centroid.y)
        ]
        
        for ponto in pontos_extremos:
            if self.perimetro_internalizado.contains(Point(ponto)):
                # Linha do centroide ao ponto
                linha = LineString([centroid.coords[0], ponto])
                intersecao = linha.intersection(self.perimetro_internalizado)
                if isinstance(intersecao, LineString) and intersecao.length > 0:
                    linhas_viarias.append(intersecao)
        
        # Estratégia 3: Linhas aleatórias criativas (se fator de criatividade alto)
        if self.fator_criatividade > 0.7:
            num_aleatorias = int(self.fator_criatividade * 5)
            for _ in range(num_aleatorias):
                # Pontos aleatórios dentro do perímetro
                x1 = random.uniform(min_x, max_x)
                y1 = random.uniform(min_y, max_y)
                x2 = random.uniform(min_x, max_x)
                y2 = random.uniform(min_y, max_y)
                
                if (self.perimetro_internalizado.contains(Point(x1, y1)) and 
                    self.perimetro_internalizado.contains(Point(x2, y2))):
                    
                    linha = LineString([(x1, y1), (x2, y2)])
                    intersecao = linha.intersection(self.perimetro_internalizado)
                    if isinstance(intersecao, LineString) and intersecao.length > 0:
                        linhas_viarias.append(intersecao)
        
        self.malha_viaria = linhas_viarias
    
    def _gerar_ruas_e_calcadas(self):
        """Gera ruas e calçadas a partir da malha viária"""
        if not self.malha_viaria:
            self.ruas = []
            self.calcadas = []
            return
        
        largura_rua = self.parametros['largura_rua']
        largura_calcada = self.parametros['largura_calcada']
        
        try:
            linhas_unidas = unary_union(self.malha_viaria)
            
            # Criar ruas
            ruas_buffer = linhas_unidas.buffer(largura_rua / 2)
            if isinstance(ruas_buffer, Polygon):
                self.ruas = [ruas_buffer]
            elif hasattr(ruas_buffer, 'geoms'):
                self.ruas = [geom for geom in ruas_buffer.geoms if isinstance(geom, Polygon)]
            else:
                self.ruas = []
            
            # Criar calçadas
            calcadas_buffer = linhas_unidas.buffer((largura_rua + 2 * largura_calcada) / 2)
            if self.ruas:
                ruas_unidas = unary_union(self.ruas)
                area_calcadas = calcadas_buffer.difference(ruas_unidas)
                
                if isinstance(area_calcadas, Polygon):
                    self.calcadas = [area_calcadas]
                elif hasattr(area_calcadas, 'geoms'):
                    self.calcadas = [geom for geom in area_calcadas.geoms if isinstance(geom, Polygon)]
                else:
                    self.calcadas = []
            else:
                self.calcadas = []
                
        except Exception as e:
            print(f"Erro ao gerar ruas e calçadas: {e}")
            self.ruas = []
            self.calcadas = []
    
    def formar_quadras_criativas(self):
        """
        Forma quadras com liberdade criativa total.
        """
        try:
            if not self.malha_viaria:
                # Se não há malha viária, usar o perímetro como quadra única
                self.quadras = [self.perimetro_internalizado]
                return
            
            # Subtrair ruas do perímetro para formar quadras
            area_disponivel = self.perimetro_internalizado
            
            if self.ruas:
                ruas_unidas = unary_union(self.ruas)
                area_disponivel = area_disponivel.difference(ruas_unidas)
            
            # Processar resultado
            if isinstance(area_disponivel, Polygon):
                self.quadras = [area_disponivel]
            elif isinstance(area_disponivel, MultiPolygon):
                self.quadras = [geom for geom in area_disponivel.geoms if isinstance(geom, Polygon)]
            else:
                self.quadras = [self.perimetro_internalizado]
            
            # Filtrar quadras muito pequenas
            area_minima_quadra = self.parametros['area_minima_lote'] * 3
            self.quadras = [q for q in self.quadras if q.area >= area_minima_quadra]
            
            print(f"Quadras criativas formadas: {len(self.quadras)}")
            for i, quadra in enumerate(self.quadras):
                print(f"  Quadra {i+1}: {quadra.area:.2f} m²")
                
        except Exception as e:
            print(f"Erro na formação de quadras: {e}")
            self.quadras = [self.perimetro_internalizado]
    
    def _gerar_hipotese_eixo_principal(self) -> List[LineString]:
        """
        NOVA FUNCIONALIDADE: Gera hipótese de malha viária alinhada com o eixo principal do terreno.
        """
        try:
            # Calcular eixo principal usando PCA ou bounding box orientado
            coords = list(self.perimetro_internalizado.exterior.coords)
            coords_array = np.array(coords[:-1])  # Remover último ponto duplicado
            
            # Calcular centroide
            centroide = np.mean(coords_array, axis=0)
            
            # Calcular matriz de covariância
            coords_centered = coords_array - centroide
            cov_matrix = np.cov(coords_centered.T)
            
            # Calcular autovalores e autovetores
            eigenvalues, eigenvectors = np.linalg.eig(cov_matrix)
            
            # O autovetor com maior autovalor é o eixo principal
            principal_axis = eigenvectors[:, np.argmax(eigenvalues)]
            
            # Normalizar
            principal_axis = principal_axis / np.linalg.norm(principal_axis)
            
            # Gerar malha alinhada com o eixo principal
            return self._gerar_malha_alinhada(principal_axis, centroide)
            
        except Exception as e:
            print(f"Erro ao gerar hipótese do eixo principal: {e}")
            return self._criar_malha_retangular_simples()
    
    def _gerar_hipotese_maior_segmento(self) -> List[LineString]:
        """
        NOVA FUNCIONALIDADE: Gera hipótese alinhada com o maior segmento da borda.
        """
        try:
            coords = list(self.perimetro_internalizado.exterior.coords)
            
            # Encontrar o maior segmento
            maior_segmento = None
            maior_comprimento = 0
            
            for i in range(len(coords) - 1):
                segmento = LineString([coords[i], coords[i + 1]])
                if segmento.length > maior_comprimento:
                    maior_comprimento = segmento.length
                    maior_segmento = segmento
            
            if maior_segmento:
                # Calcular direção do maior segmento
                p1, p2 = maior_segmento.coords[0], maior_segmento.coords[1]
                direcao = np.array([p2[0] - p1[0], p2[1] - p1[1]])
                direcao = direcao / np.linalg.norm(direcao)
                
                # Centroide do perímetro
                centroide = np.array([self.perimetro_internalizado.centroid.x, 
                                    self.perimetro_internalizado.centroid.y])
                
                return self._gerar_malha_alinhada(direcao, centroide)
            else:
                return self._criar_malha_retangular_simples()
                
        except Exception as e:
            print(f"Erro ao gerar hipótese do maior segmento: {e}")
            return self._criar_malha_retangular_simples()
    
    def _gerar_hipotese_orientacao_solar(self) -> List[LineString]:
        """
        NOVA FUNCIONALIDADE: Gera hipótese com orientação solar (Norte-Sul / Leste-Oeste).
        """
        try:
            # Orientação Norte-Sul (eixo Y)
            direcao_ns = np.array([0, 1])
            centroide = np.array([self.perimetro_internalizado.centroid.x, 
                                self.perimetro_internalizado.centroid.y])
            
            return self._gerar_malha_alinhada(direcao_ns, centroide)
            
        except Exception as e:
            print(f"Erro ao gerar hipótese de orientação solar: {e}")
            return self._criar_malha_retangular_simples()
    
    def _gerar_malha_alinhada(self, direcao: np.ndarray, centroide: np.ndarray) -> List[LineString]:
        """
        Gera malha viária alinhada com uma direção específica.
        """
        try:
            bounds = self.perimetro_internalizado.bounds
            min_x, min_y, max_x, max_y = bounds
            
            # Direção perpendicular
            direcao_perp = np.array([-direcao[1], direcao[0]])
            
            linhas_viarias = []
            profundidade_max = self.parametros['profundidade_max_quadra']
            
            # Calcular extensão do terreno nas duas direções
            diagonal = np.sqrt((max_x - min_x)**2 + (max_y - min_y)**2)
            
            # Linhas paralelas à direção principal
            num_linhas_principais = max(2, int(diagonal / profundidade_max))
            for i in range(1, num_linhas_principais):
                offset = (i - num_linhas_principais/2) * profundidade_max
                ponto_inicio = centroide + offset * direcao_perp
                ponto_fim = ponto_inicio + diagonal * direcao
                
                linha = LineString([ponto_inicio, ponto_fim])
                intersecao = linha.intersection(self.perimetro_internalizado)
                
                if isinstance(intersecao, LineString) and intersecao.length > 0:
                    linhas_viarias.append(intersecao)
                elif hasattr(intersecao, 'geoms'):
                    for geom in intersecao.geoms:
                        if isinstance(geom, LineString) and geom.length > 0:
                            linhas_viarias.append(geom)
            
            # Linhas perpendiculares
            num_linhas_perp = max(2, int(diagonal / profundidade_max))
            for i in range(1, num_linhas_perp):
                offset = (i - num_linhas_perp/2) * profundidade_max
                ponto_inicio = centroide + offset * direcao
                ponto_fim = ponto_inicio + diagonal * direcao_perp
                
                linha = LineString([ponto_inicio, ponto_fim])
                intersecao = linha.intersection(self.perimetro_internalizado)
                
                if isinstance(intersecao, LineString) and intersecao.length > 0:
                    linhas_viarias.append(intersecao)
                elif hasattr(intersecao, 'geoms'):
                    for geom in intersecao.geoms:
                        if isinstance(geom, LineString) and geom.length > 0:
                            linhas_viarias.append(geom)
            
            return linhas_viarias
            
        except Exception as e:
            print(f"Erro ao gerar malha alinhada: {e}")
            return []
    
    def _calcular_pontuacao(self, malha_viaria: List[LineString]) -> float:
        """
        NOVA FUNCIONALIDADE: Calcula pontuação de uma hipótese de malha viária.
        """
        try:
            if not malha_viaria:
                return 0.0
            
            pontuacao = 0.0
            
            # 1. Estimativa de lotes potenciais (40% da pontuação)
            area_total = self.perimetro_internalizado.area
            area_ruas = sum([linha.buffer(self.parametros['largura_rua']/2).area for linha in malha_viaria])
            area_lotes_estimada = area_total - area_ruas
            lotes_estimados = area_lotes_estimada / self.parametros['area_minima_lote']
            pontuacao += lotes_estimados * 0.4
            
            # 2. Aproveitamento de área (30% da pontuação)
            aproveitamento = area_lotes_estimada / area_total
            pontuacao += aproveitamento * 100 * 0.3
            
            # 3. Penalidade por ruas em áreas de alta declividade (20% da pontuação)
            if self.topografia_map and self.topografia_map.get('areas_alta_declividade'):
                penalidade_topografia = 0
                for linha in malha_viaria:
                    for ponto_alto in self.topografia_map['areas_alta_declividade']:
                        if linha.distance(ponto_alto) < 20:  # 20 metros de tolerância
                            penalidade_topografia += 1
                
                # Converter penalidade em pontos (menos penalidade = mais pontos)
                max_penalidade = len(malha_viaria) * len(self.topografia_map['areas_alta_declividade']) / 10
                if max_penalidade > 0:
                    pontos_topografia = (1 - penalidade_topografia / max_penalidade) * 20
                    pontuacao += pontos_topografia * 0.2
            else:
                pontuacao += 10 * 0.2  # Pontuação neutra se não há dados topográficos
            
            # 4. Pontos por alinhamento solar (10% da pontuação)
            criterio_orientacao = self.parametros.get('criterio_orientacao_arruamento', '')
            if 'Solar' in criterio_orientacao:
                pontos_solar = 0
                for linha in malha_viaria:
                    coords = list(linha.coords)
                    if len(coords) >= 2:
                        dx = coords[-1][0] - coords[0][0]
                        dy = coords[-1][1] - coords[0][1]
                        angulo = np.arctan2(dy, dx) * 180 / np.pi
                        
                        # Pontos por alinhamento Norte-Sul (0°, 180°) ou Leste-Oeste (90°, 270°)
                        angulo_normalizado = abs(angulo) % 90
                        if angulo_normalizado < 15 or angulo_normalizado > 75:  # Próximo aos eixos cardeais
                            pontos_solar += 1
                
                pontuacao += pontos_solar * 0.1
            else:
                pontuacao += 5 * 0.1  # Pontuação neutra
            
            return pontuacao
            
        except Exception as e:
            print(f"Erro ao calcular pontuação: {e}")
            return 0.0
    
    def _criar_malha_retangular_simples(self) -> List[LineString]:
        """
        Cria uma malha retangular simples como fallback.
        """
        bounds = self.perimetro_internalizado.bounds
        min_x, min_y, max_x, max_y = bounds
        
        linhas_viarias = []
        profundidade_max = self.parametros['profundidade_max_quadra']
        
        # Linhas verticais
        largura_total = max_x - min_x
        num_verticais = max(1, int(largura_total / profundidade_max))
        for i in range(1, num_verticais + 1):
            x = min_x + (i * largura_total / (num_verticais + 1))
            linha = LineString([(x, min_y), (x, max_y)])
            intersecao = linha.intersection(self.perimetro_internalizado)
            if isinstance(intersecao, LineString) and intersecao.length > 0:
                linhas_viarias.append(intersecao)
        
        # Linhas horizontais
        altura_total = max_y - min_y
        num_horizontais = max(1, int(altura_total / profundidade_max))
        for i in range(1, num_horizontais + 1):
            y = min_y + (i * altura_total / (num_horizontais + 1))
            linha = LineString([(min_x, y), (max_x, y)])
            intersecao = linha.intersection(self.perimetro_internalizado)
            if isinstance(intersecao, LineString) and intersecao.length > 0:
                linhas_viarias.append(intersecao)
        
        return linhas_viarias
    
    def formar_quadras_com_refinamento(self):
        """
        NOVA FUNCIONALIDADE: Forma quadras com passo de limpeza e refinamento.
        """
        try:
            # Primeiro, formar quadras normalmente
            self.formar_quadras_criativas()
            
            # Aplicar passo de limpeza
            print("Aplicando passo de limpeza nas quadras...")
            self._refinar_quadras()
            
        except Exception as e:
            print(f"Erro na formação de quadras com refinamento: {e}")
            self.quadras = [self.perimetro_internalizado]
    
    def _refinar_quadras(self):
        """
        NOVA FUNCIONALIDADE: Implementa o passo de limpeza para quadras.
        """
        try:
            if not self.quadras:
                return
            
            area_minima_quadra_limpeza = self.parametros['area_minima_lote'] * 5  # 5 lotes mínimos
            quadras_refinadas = []
            quadras_pequenas = []
            
            # Separar quadras grandes e pequenas
            for quadra in self.quadras:
                if quadra.area >= area_minima_quadra_limpeza:
                    quadras_refinadas.append(quadra)
                else:
                    quadras_pequenas.append(quadra)
            
            # Tentar mesclar quadras pequenas com vizinhas
            for quadra_pequena in quadras_pequenas:
                melhor_vizinha = None
                menor_distancia = float('inf')
                
                # Encontrar a quadra vizinha mais próxima
                for quadra_grande in quadras_refinadas:
                    distancia = quadra_pequena.distance(quadra_grande)
                    if distancia < menor_distancia:
                        menor_distancia = distancia
                        melhor_vizinha = quadra_grande
                
                # Se encontrou uma vizinha próxima, tentar mesclar
                if melhor_vizinha and menor_distancia < 10:  # 10 metros de tolerância
                    try:
                        quadra_mesclada = unary_union([quadra_pequena, melhor_vizinha])
                        if isinstance(quadra_mesclada, Polygon):
                            # Substituir a quadra grande pela mesclada
                            indice = quadras_refinadas.index(melhor_vizinha)
                            quadras_refinadas[indice] = quadra_mesclada
                        else:
                            # Se a mesclagem não resultou em polígono único, manter separadas
                            quadras_refinadas.append(quadra_pequena)
                    except:
                        # Se a mesclagem falhou, manter a quadra pequena
                        quadras_refinadas.append(quadra_pequena)
                else:
                    # Se não encontrou vizinha próxima, manter a quadra pequena
                    quadras_refinadas.append(quadra_pequena)
            
            self.quadras = quadras_refinadas
            print(f"Refinamento concluído: {len(self.quadras)} quadras finais")
            
        except Exception as e:
            print(f"Erro no refinamento de quadras: {e}")
            # Manter quadras originais em caso de erro
    
    def subdividir_quadras_ultra_otimizado(self):
        """
        Subdivisão ultra-otimizada com foco em aproveitamento máximo e lotes de esquina.
        """
        try:
            self.lotes = []
            
            for i, quadra in enumerate(self.quadras):
                print(f"Processando quadra {i+1}: área = {quadra.area:.2f} m²")
                
                # Estratégia baseada no tamanho da quadra
                if quadra.area < self.parametros['area_minima_lote'] * 2:
                    # Quadra pequena: usar como lote único
                    if self._quadra_tem_acesso_rua(quadra):
                        self.lotes.append(quadra)
                        print(f"  Quadra {i+1} convertida em lote único")
                else:
                    # Quadra grande: subdividir otimizadamente
                    lotes_quadra = self._subdividir_quadra_otimizada(quadra, i+1)
                    self.lotes.extend(lotes_quadra)
                    print(f"  Lotes criados na quadra {i+1}: {len(lotes_quadra)}")
            
            print(f"Total de lotes criados: {len(self.lotes)}")
            
        except Exception as e:
            print(f"Erro na subdivisão ultra-otimizada: {e}")
    
    def _subdividir_quadra_otimizada(self, quadra: Polygon, numero_quadra: int) -> List[Polygon]:
        """
        Subdivide uma quadra de forma otimizada considerando:
        - Lotes de esquina com orientação otimizada
        - Máximo aproveitamento de área
        - Distribuição inteligente
        """
        lotes = []
        
        try:
            # Analisar a geometria da quadra
            analise = self._analisar_geometria_quadra(quadra)
            
            # Estratégia 1: Lotes de esquina otimizados
            lotes_esquina = self._criar_lotes_esquina_otimizados(quadra, analise)
            lotes.extend(lotes_esquina)
            
            # Calcular área restante
            if lotes_esquina:
                area_usada = unary_union(lotes_esquina)
                area_restante = quadra.difference(area_usada)
            else:
                area_restante = quadra
            
            # Estratégia 2: Lotes ao longo das bordas
            if isinstance(area_restante, Polygon) and area_restante.area > self.parametros['area_minima_lote']:
                lotes_bordas = self._criar_lotes_bordas_otimizados(area_restante, analise)
                lotes.extend(lotes_bordas)
                
                # Atualizar área restante
                if lotes_bordas:
                    area_usada_bordas = unary_union(lotes_bordas)
                    area_restante = area_restante.difference(area_usada_bordas)
            
            # Estratégia 3: Lotes no centro (se sobrar área significativa)
            if isinstance(area_restante, Polygon) and area_restante.area > self.parametros['area_minima_lote']:
                lotes_centro = self._criar_lotes_centro_adaptativos(area_restante)
                lotes.extend(lotes_centro)
            
            # Filtrar lotes muito pequenos
            lotes_validos = []
            for lote in lotes:
                if isinstance(lote, Polygon) and lote.area >= self.parametros['area_minima_lote']:
                    lotes_validos.append(lote)
            
            return lotes_validos
            
        except Exception as e:
            print(f"Erro na subdivisão otimizada da quadra {numero_quadra}: {e}")
            return []
    
    def _analisar_geometria_quadra(self, quadra: Polygon) -> Dict[str, Any]:
        """
        Analisa a geometria da quadra para otimizar a subdivisão.
        """
        bounds = quadra.bounds
        min_x, min_y, max_x, max_y = bounds
        
        largura = max_x - min_x
        altura = max_y - min_y
        area = quadra.area
        perimetro = quadra.length
        
        # Calcular compacidade (relação área/perímetro)
        compacidade = (4 * math.pi * area) / (perimetro ** 2)
        
        # Identificar orientação principal
        if largura > altura * 1.5:
            orientacao = 'horizontal'
        elif altura > largura * 1.5:
            orientacao = 'vertical'
        else:
            orientacao = 'quadrada'
        
        # Encontrar cantos/esquinas
        coords = list(quadra.exterior.coords)[:-1]
        esquinas = self._identificar_esquinas(coords)
        
        return {
            'largura': largura,
            'altura': altura,
            'area': area,
            'perimetro': perimetro,
            'compacidade': compacidade,
            'orientacao': orientacao,
            'esquinas': esquinas,
            'coords': coords,
            'bounds': bounds
        }
    
    def _identificar_esquinas(self, coords: List[Tuple[float, float]]) -> List[Dict[str, Any]]:
        """
        Identifica esquinas e suas características.
        """
        esquinas = []
        n = len(coords)
        
        for i in range(n):
            p1 = coords[i-1]
            p2 = coords[i]
            p3 = coords[(i+1) % n]
            
            # Calcular ângulo
            v1 = (p1[0] - p2[0], p1[1] - p2[1])
            v2 = (p3[0] - p2[0], p3[1] - p2[1])
            
            # Produto escalar e magnitudes
            dot_product = v1[0] * v2[0] + v1[1] * v2[1]
            mag1 = math.sqrt(v1[0]**2 + v1[1]**2)
            mag2 = math.sqrt(v2[0]**2 + v2[1]**2)
            
            if mag1 > 0 and mag2 > 0:
                cos_angle = dot_product / (mag1 * mag2)
                cos_angle = max(-1, min(1, cos_angle))  # Clamp para evitar erros
                angulo = math.acos(cos_angle)
                angulo_graus = math.degrees(angulo)
                
                # Considerar como esquina se o ângulo for significativo
                if angulo_graus < 150:  # Ângulo menor que 150° é considerado esquina
                    esquinas.append({
                        'ponto': p2,
                        'angulo': angulo_graus,
                        'indice': i,
                        'tipo': 'convexa' if angulo_graus < 90 else 'suave'
                    })
        
        return esquinas
    
    def _criar_lotes_esquina_otimizados(self, quadra: Polygon, analise: Dict[str, Any]) -> List[Polygon]:
        """
        Cria lotes de esquina com orientação otimizada.
        """
        lotes_esquina = []
        estrategia = self.parametros.get('estrategia_esquina', 'Automático')
        
        try:
            esquinas = analise['esquinas']
            
            for esquina in esquinas:
                if esquina['angulo'] < 120:  # Apenas esquinas bem definidas
                    lote_esquina = self._criar_lote_esquina_individual(quadra, esquina, estrategia, analise)
                    if lote_esquina:
                        lotes_esquina.append(lote_esquina)
            
            return lotes_esquina
            
        except Exception as e:
            print(f"Erro ao criar lotes de esquina: {e}")
            return []
    
    def _criar_lote_esquina_individual(self, quadra: Polygon, esquina: Dict[str, Any], 
                                     estrategia: str, analise: Dict[str, Any]) -> Optional[Polygon]:
        """
        MODIFICADO: Cria um lote de esquina individual com lógica de canto aplicada.
        """
        try:
            ponto_esquina = esquina['ponto']
            coords = analise['coords']
            indice = esquina['indice']
            
            # Determinar dimensões do lote de esquina
            if estrategia == 'Testada Maior':
                testada = self.parametros.get('testada_maxima_lote', 20.0)
                profundidade = self.parametros.get('profundidade_minima_lote', 15.0)
            elif estrategia == 'Testada Menor':
                testada = self.parametros['testada_minima_lote']
                profundidade = self.parametros['profundidade_padrao_lote']
            elif estrategia == 'Área Maior':
                area_desejada = self.parametros.get('area_maxima_lote', 600.0)
                testada = math.sqrt(area_desejada * 1.5)  # Proporção 1.5:1
                profundidade = area_desejada / testada
            else:  # Automático
                testada = self.parametros['largura_padrao_lote']
                profundidade = self.parametros['profundidade_padrao_lote']
            
            # Criar lote de esquina básico
            lote_esquina = self._criar_retangulo_esquina(ponto_esquina, testada, profundidade, coords, indice)
            
            if lote_esquina and isinstance(lote_esquina, Polygon):
                # NOVA FUNCIONALIDADE: Aplicar lógica de canto
                lote_com_canto = self._aplicar_logica_canto(lote_esquina, esquina)
                
                # Verificar se o lote está dentro da quadra
                if lote_com_canto and quadra.contains(lote_com_canto):
                    # Adicionar à lista de lotes de esquina para classificação
                    self.lotes_esquina.append(lote_com_canto)
                    return lote_com_canto
                elif lote_com_canto:
                    # Se não está totalmente dentro, tentar interseção
                    intersecao = lote_com_canto.intersection(quadra)
                    if isinstance(intersecao, Polygon) and intersecao.area >= self.parametros['area_minima_lote']:
                        self.lotes_esquina.append(intersecao)
                        return intersecao
            
            return None
            
        except Exception as e:
            print(f"Erro ao criar lote de esquina individual: {e}")
            return None
    
    def _aplicar_logica_canto(self, lote: Polygon, esquina: Dict[str, Any]) -> Optional[Polygon]:
        """
        NOVA FUNCIONALIDADE: Aplica lógica de canto conforme parâmetros do usuário.
        """
        try:
            tratamento = self.parametros.get('tratamento_lotes_esquina', 'Manter Quina Viva (90°)')
            
            if 'Manter Quina Viva' in tratamento:
                # Não aplicar modificação, manter o lote original
                return lote
            
            elif 'Chanfrar' in tratamento:
                # Aplicar chanfro
                distancia_chanfro = self.parametros.get('distancia_chanfro', 3.0)
                return self._aplicar_chanfro(lote, esquina, distancia_chanfro)
            
            elif 'Aplicar Raio de Curvatura' in tratamento:
                # Aplicar raio de curvatura
                raio_curvatura = self.parametros.get('raio_curvatura', 5.0)
                return self._aplicar_raio_curvatura(lote, esquina, raio_curvatura)
            
            else:
                return lote
                
        except Exception as e:
            print(f"Erro ao aplicar lógica de canto: {e}")
            return lote
    
    def _aplicar_chanfro(self, lote: Polygon, esquina: Dict[str, Any], distancia: float) -> Optional[Polygon]:
        """
        Aplica chanfro ao lote de esquina.
        """
        try:
            # Encontrar o vértice da esquina no lote
            ponto_esquina = Point(esquina['ponto'])
            coords_lote = list(lote.exterior.coords)
            
            # Encontrar o vértice mais próximo da esquina
            vertice_esquina = None
            menor_distancia = float('inf')
            indice_vertice = -1
            
            for i, coord in enumerate(coords_lote[:-1]):  # Excluir último ponto duplicado
                ponto = Point(coord)
                dist = ponto_esquina.distance(ponto)
                if dist < menor_distancia:
                    menor_distancia = dist
                    vertice_esquina = coord
                    indice_vertice = i
            
            if vertice_esquina and menor_distancia < 10:  # Tolerância de 10 metros
                # Criar chanfro removendo um pequeno triângulo da esquina
                coords_modificados = coords_lote.copy()
                
                # Calcular pontos do chanfro
                if indice_vertice > 0 and indice_vertice < len(coords_modificados) - 2:
                    p_anterior = coords_modificados[indice_vertice - 1]
                    p_esquina = coords_modificados[indice_vertice]
                    p_posterior = coords_modificados[indice_vertice + 1]
                    
                    # Calcular direções
                    dir_anterior = np.array([p_esquina[0] - p_anterior[0], p_esquina[1] - p_anterior[1]])
                    dir_posterior = np.array([p_posterior[0] - p_esquina[0], p_posterior[1] - p_esquina[1]])
                    
                    # Normalizar
                    if np.linalg.norm(dir_anterior) > 0:
                        dir_anterior = dir_anterior / np.linalg.norm(dir_anterior)
                    if np.linalg.norm(dir_posterior) > 0:
                        dir_posterior = dir_posterior / np.linalg.norm(dir_posterior)
                    
                    # Calcular pontos do chanfro
                    ponto_chanfro_1 = (p_esquina[0] - dir_anterior[0] * distancia,
                                      p_esquina[1] - dir_anterior[1] * distancia)
                    ponto_chanfro_2 = (p_esquina[0] + dir_posterior[0] * distancia,
                                      p_esquina[1] + dir_posterior[1] * distancia)
                    
                    # Substituir o vértice da esquina pelos pontos do chanfro
                    coords_modificados[indice_vertice] = ponto_chanfro_1
                    coords_modificados.insert(indice_vertice + 1, ponto_chanfro_2)
                    
                    # Criar novo polígono
                    lote_chanfrado = Polygon(coords_modificados)
                    if lote_chanfrado.is_valid:
                        return lote_chanfrado
            
            return lote
            
        except Exception as e:
            print(f"Erro ao aplicar chanfro: {e}")
            return lote
    
    def _aplicar_raio_curvatura(self, lote: Polygon, esquina: Dict[str, Any], raio: float) -> Optional[Polygon]:
        """
        Aplica raio de curvatura ao lote de esquina.
        """
        try:
            # Aplicar buffer positivo pequeno para arredondar cantos
            lote_arredondado = lote.buffer(raio/2, join_style=1)  # join_style=1 para cantos arredondados
            
            # Depois aplicar buffer negativo para voltar ao tamanho original
            lote_final = lote_arredondado.buffer(-raio/2, join_style=1)
            
            if isinstance(lote_final, Polygon) and lote_final.is_valid:
                return lote_final
            else:
                return lote
                
        except Exception as e:
            print(f"Erro ao aplicar raio de curvatura: {e}")
            return lote
    
    def _criar_lotes_bordas_otimizados(self, area_restante: Polygon, analise: Dict[str, Any]) -> List[Polygon]:
        """
        Cria lotes otimizados ao longo das bordas.
        """
        lotes_bordas = []
        
        try:
            # Encontrar bordas com acesso à rua
            bordas_com_rua = self._encontrar_bordas_com_rua(area_restante)
            
            for borda in bordas_com_rua:
                lotes_borda = self._subdividir_borda_inteligente(area_restante, borda)
                lotes_bordas.extend(lotes_borda)
            
            return lotes_bordas
            
        except Exception as e:
            print(f"Erro ao criar lotes de bordas: {e}")
            return []
    
    def _subdividir_borda_inteligente(self, area: Polygon, borda: LineString) -> List[Polygon]:
        """
        Subdivide uma borda de forma inteligente.
        """
        lotes = []
        
        try:
            comprimento_borda = borda.length
            
            # Calcular número ótimo de lotes
            testada_preferencial = self.parametros['testada_preferencial_lote']
            num_lotes_ideal = max(1, int(comprimento_borda / testada_preferencial))
            
            # Ajustar baseado na densidade desejada
            num_lotes_final = int(num_lotes_ideal * self.fator_densidade)
            num_lotes_final = max(1, num_lotes_final)
            
            largura_lote = comprimento_borda / num_lotes_final
            
            # Criar lotes ao longo da borda
            for i in range(num_lotes_final):
                inicio_norm = i / num_lotes_final
                fim_norm = (i + 1) / num_lotes_final
                
                lote = self._criar_lote_ao_longo_borda(area, borda, inicio_norm, fim_norm, largura_lote)
                if lote and lote.area >= self.parametros['area_minima_lote']:
                    lotes.append(lote)
            
            return lotes
            
        except Exception as e:
            print(f"Erro na subdivisão inteligente de borda: {e}")
            return []
    
    def _criar_lote_ao_longo_borda(self, area: Polygon, borda: LineString, 
                                  inicio_norm: float, fim_norm: float, largura: float) -> Optional[Polygon]:
        """
        Cria um lote ao longo de uma borda específica.
        """
        try:
            # Pontos ao longo da borda
            p1 = borda.interpolate(inicio_norm, normalized=True)
            p2 = borda.interpolate(fim_norm, normalized=True)
            
            # Vetor da borda
            dx = p2.x - p1.x
            dy = p2.y - p1.y
            
            # Vetor perpendicular (para dentro da área)
            perp_x = -dy
            perp_y = dx
            
            # Normalizar
            mag = math.sqrt(perp_x**2 + perp_y**2)
            if mag > 0:
                perp_x /= mag
                perp_y /= mag
            
            # Determinar profundidade adaptativa
            profundidade_max = self.parametros['profundidade_maxima_lote']
            profundidade_min = self.parametros['profundidade_minima_lote']
            
            # Tentar diferentes profundidades
            for fator in [1.0, 0.8, 0.6, 1.2, 1.5]:
                profundidade = min(profundidade_max, profundidade_min * fator)
                
                # Criar retângulo
                pontos = [
                    (p1.x, p1.y),
                    (p2.x, p2.y),
                    (p2.x + perp_x * profundidade, p2.y + perp_y * profundidade),
                    (p1.x + perp_x * profundidade, p1.y + perp_y * profundidade)
                ]
                
                lote_tentativa = Polygon(pontos)
                lote_final = lote_tentativa.intersection(area)
                
                if isinstance(lote_final, Polygon) and lote_final.area >= self.parametros['area_minima_lote']:
                    return lote_final
            
            return None
            
        except Exception as e:
            print(f"Erro ao criar lote ao longo da borda: {e}")
            return None
    
    def _criar_lotes_centro_adaptativos(self, area_restante: Polygon) -> List[Polygon]:
        """
        MODIFICADO: Cria lotes adaptativos no centro com validação iterativa.
        """
        lotes_centro = []
        
        try:
            if area_restante.area < self.parametros['area_minima_lote'] * 2:
                # Área pequena: usar como lote único
                if area_restante.area >= self.parametros['area_minima_lote']:
                    lotes_centro.append(area_restante)
                return lotes_centro
            
            # Estratégia baseada na forma da área
            bounds = area_restante.bounds
            min_x, min_y, max_x, max_y = bounds
            largura = max_x - min_x
            altura = max_y - min_y
            
            if largura > altura * 2:
                # Área alongada horizontalmente: dividir verticalmente
                lotes_preliminares = self._dividir_verticalmente(area_restante)
            elif altura > largura * 2:
                # Área alongada verticalmente: dividir horizontalmente
                lotes_preliminares = self._dividir_horizontalmente(area_restante)
            else:
                # Área aproximadamente quadrada: usar triangulação
                lotes_preliminares = self._triangular_area_adaptativa(area_restante)
            
            # NOVA FUNCIONALIDADE: Aplicar validação iterativa
            lotes_validados = self._aplicar_validacao_iterativa(lotes_preliminares, area_restante)
            
            return lotes_validados
            
        except Exception as e:
            print(f"Erro ao criar lotes centro adaptativos: {e}")
            return []
    
    def _aplicar_validacao_iterativa(self, lotes_preliminares: List[Polygon], area_original: Polygon) -> List[Polygon]:
        """
        NOVA FUNCIONALIDADE: Aplica validação iterativa na subdivisão de lotes.
        """
        try:
            lotes_validados = []
            lotes_problematicos = []
            
            # Primeira passada: identificar lotes válidos e problemáticos
            for lote in lotes_preliminares:
                if self._validar_lote(lote):
                    lotes_validados.append(lote)
                else:
                    lotes_problematicos.append(lote)
            
            # Segunda passada: tentar corrigir lotes problemáticos
            for lote_problematico in lotes_problematicos:
                lote_corrigido = self._corrigir_lote_problematico(lote_problematico, lotes_validados, area_original)
                if lote_corrigido:
                    if isinstance(lote_corrigido, list):
                        lotes_validados.extend(lote_corrigido)
                    else:
                        lotes_validados.append(lote_corrigido)
                else:
                    # Se não conseguiu corrigir, marcar como atípico
                    self.lotes_atipicos.append(lote_problematico)
            
            return lotes_validados
            
        except Exception as e:
            print(f"Erro na validação iterativa: {e}")
            return lotes_preliminares
    
    def _validar_lote(self, lote: Polygon) -> bool:
        """
        Valida se um lote atende aos critérios mínimos.
        """
        try:
            # Verificar área mínima
            if lote.area < self.parametros['area_minima_lote']:
                return False
            
            # Verificar testada mínima (aproximação usando bounding box)
            bounds = lote.bounds
            min_x, min_y, max_x, max_y = bounds
            largura = max_x - min_x
            altura = max_y - min_y
            
            testada_estimada = min(largura, altura)
            if testada_estimada < self.parametros['testada_minima_lote']:
                return False
            
            # Verificar se o lote não é muito irregular (razão de aspecto)
            razao_aspecto = max(largura, altura) / min(largura, altura)
            if razao_aspecto > 5:  # Muito alongado
                return False
            
            # Verificar se o polígono é válido
            if not lote.is_valid:
                return False
            
            return True
            
        except Exception as e:
            print(f"Erro na validação do lote: {e}")
            return False
    
    def _corrigir_lote_problematico(self, lote_problematico: Polygon, lotes_vizinhos: List[Polygon], 
                                   area_original: Polygon) -> Optional[Polygon]:
        """
        Tenta corrigir um lote problemático expandindo-o ou fundindo-o com vizinhos.
        """
        try:
            # Estratégia 1: Tentar expandir o lote
            if lote_problematico.area < self.parametros['area_minima_lote']:
                lote_expandido = self._tentar_expandir_lote(lote_problematico, lotes_vizinhos, area_original)
                if lote_expandido and self._validar_lote(lote_expandido):
                    return lote_expandido
            
            # Estratégia 2: Tentar fundir com vizinho mais próximo
            vizinho_mais_proximo = self._encontrar_vizinho_mais_proximo(lote_problematico, lotes_vizinhos)
            if vizinho_mais_proximo:
                lote_fundido = self._tentar_fundir_lotes(lote_problematico, vizinho_mais_proximo)
                if lote_fundido and self._validar_lote(lote_fundido):
                    # Remover o vizinho da lista e retornar o lote fundido
                    if vizinho_mais_proximo in lotes_vizinhos:
                        lotes_vizinhos.remove(vizinho_mais_proximo)
                    return lote_fundido
            
            # Estratégia 3: Se não conseguiu corrigir, retornar None (será marcado como atípico)
            return None
            
        except Exception as e:
            print(f"Erro ao corrigir lote problemático: {e}")
            return None
    
    def _tentar_expandir_lote(self, lote: Polygon, lotes_vizinhos: List[Polygon], 
                             area_original: Polygon) -> Optional[Polygon]:
        """
        Tenta expandir um lote pequeno para atingir a área mínima.
        """
        try:
            area_necessaria = self.parametros['area_minima_lote']
            area_atual = lote.area
            
            if area_atual >= area_necessaria:
                return lote
            
            # Calcular fator de expansão necessário
            fator_expansao = math.sqrt(area_necessaria / area_atual)
            
            # Expandir o lote usando buffer
            lote_expandido = lote.buffer(fator_expansao)
            
            # Verificar se a expansão não invade outros lotes
            for vizinho in lotes_vizinhos:
                if lote_expandido.intersects(vizinho):
                    # Se invade, tentar expansão menor
                    lote_expandido = lote.buffer(fator_expansao * 0.5)
                    break
            
            # Garantir que está dentro da área original
            lote_final = lote_expandido.intersection(area_original)
            
            if isinstance(lote_final, Polygon) and lote_final.area >= area_necessaria:
                return lote_final
            
            return None
            
        except Exception as e:
            print(f"Erro ao expandir lote: {e}")
            return None
    
    def _encontrar_vizinho_mais_proximo(self, lote: Polygon, lotes_vizinhos: List[Polygon]) -> Optional[Polygon]:
        """
        Encontra o lote vizinho mais próximo.
        """
        try:
            if not lotes_vizinhos:
                return None
            
            menor_distancia = float('inf')
            vizinho_mais_proximo = None
            
            for vizinho in lotes_vizinhos:
                distancia = lote.distance(vizinho)
                if distancia < menor_distancia:
                    menor_distancia = distancia
                    vizinho_mais_proximo = vizinho
            
            # Só considerar como vizinho se estiver próximo (menos de 10 metros)
            if menor_distancia < 10:
                return vizinho_mais_proximo
            
            return None
            
        except Exception as e:
            print(f"Erro ao encontrar vizinho mais próximo: {e}")
            return None
    
    def _tentar_fundir_lotes(self, lote1: Polygon, lote2: Polygon) -> Optional[Polygon]:
        """
        Tenta fundir dois lotes.
        """
        try:
            lote_fundido = unary_union([lote1, lote2])
            
            if isinstance(lote_fundido, Polygon) and lote_fundido.is_valid:
                return lote_fundido
            
            return None
            
        except Exception as e:
            print(f"Erro ao fundir lotes: {e}")
            return None
    
    def _dividir_verticalmente(self, area: Polygon) -> List[Polygon]:
        """Divide área verticalmente"""
        lotes = []
        bounds = area.bounds
        min_x, min_y, max_x, max_y = bounds
        
        largura_total = max_x - min_x
        testada_preferencial = self.parametros['testada_preferencial_lote']
        
        num_divisoes = max(1, int(largura_total / testada_preferencial))
        largura_divisao = largura_total / num_divisoes
        
        for i in range(num_divisoes):
            x = min_x + i * largura_divisao
            linha_corte = LineString([(x, min_y - 10), (x, max_y + 10)])
            
            if i == 0:
                # Primeira divisão
                x_fim = min_x + largura_divisao
                linha_fim = LineString([(x_fim, min_y - 10), (x_fim, max_y + 10)])
                
                # Criar polígono da divisão
                pontos_divisao = [
                    (min_x, min_y), (x_fim, min_y), (x_fim, max_y), (min_x, max_y)
                ]
                divisao = Polygon(pontos_divisao)
                lote = divisao.intersection(area)
                
                if isinstance(lote, Polygon) and lote.area >= self.parametros['area_minima_lote']:
                    lotes.append(lote)
            else:
                # Divisões intermediárias
                x_inicio = min_x + (i-1) * largura_divisao
                x_fim = min_x + i * largura_divisao
                
                pontos_divisao = [
                    (x_inicio, min_y), (x_fim, min_y), (x_fim, max_y), (x_inicio, max_y)
                ]
                divisao = Polygon(pontos_divisao)
                lote = divisao.intersection(area)
                
                if isinstance(lote, Polygon) and lote.area >= self.parametros['area_minima_lote']:
                    lotes.append(lote)
        
        return lotes
    
    def _dividir_horizontalmente(self, area: Polygon) -> List[Polygon]:
        """Divide área horizontalmente"""
        lotes = []
        bounds = area.bounds
        min_x, min_y, max_x, max_y = bounds
        
        altura_total = max_y - min_y
        profundidade_preferencial = self.parametros['profundidade_padrao_lote']
        
        num_divisoes = max(1, int(altura_total / profundidade_preferencial))
        altura_divisao = altura_total / num_divisoes
        
        for i in range(num_divisoes):
            y_inicio = min_y + i * altura_divisao
            y_fim = min_y + (i + 1) * altura_divisao
            
            pontos_divisao = [
                (min_x, y_inicio), (max_x, y_inicio), (max_x, y_fim), (min_x, y_fim)
            ]
            divisao = Polygon(pontos_divisao)
            lote = divisao.intersection(area)
            
            if isinstance(lote, Polygon) and lote.area >= self.parametros['area_minima_lote']:
                lotes.append(lote)
        
        return lotes
    
    def _triangular_area_adaptativa(self, area: Polygon) -> List[Polygon]:
        """Triangula área de forma adaptativa"""
        lotes = []
        
        try:
            coords = list(area.exterior.coords)[:-1]
            
            if len(coords) <= 4:
                # Polígono simples: dividir por diagonais
                if len(coords) == 4:
                    # Quadrilátero: dividir em 2 triângulos
                    triangulo1 = Polygon([coords[0], coords[1], coords[2]])
                    triangulo2 = Polygon([coords[0], coords[2], coords[3]])
                    
                    if triangulo1.area >= self.parametros['area_minima_lote']:
                        lotes.append(triangulo1)
                    if triangulo2.area >= self.parametros['area_minima_lote']:
                        lotes.append(triangulo2)
                else:
                    # Triângulo: usar como está se for grande o suficiente
                    if area.area >= self.parametros['area_minima_lote']:
                        lotes.append(area)
            else:
                # Polígono complexo: usar centroide para dividir
                centroide = area.centroid
                
                for i in range(len(coords)):
                    p1 = coords[i]
                    p2 = coords[(i + 1) % len(coords)]
                    
                    triangulo = Polygon([p1, p2, centroide.coords[0]])
                    triangulo_intersecao = triangulo.intersection(area)
                    
                    if isinstance(triangulo_intersecao, Polygon) and triangulo_intersecao.area >= self.parametros['area_minima_lote']:
                        lotes.append(triangulo_intersecao)
            
            return lotes
            
        except Exception as e:
            print(f"Erro na triangulação adaptativa: {e}")
            return [area] if area.area >= self.parametros['area_minima_lote'] else []
    
    def _quadra_tem_acesso_rua(self, quadra: Polygon) -> bool:
        """Verifica se a quadra tem acesso direto à rua"""
        try:
            for rua in self.ruas:
                if quadra.distance(rua) < 2.0:
                    return True
            return False
        except:
            return False
    
    def _encontrar_bordas_com_rua(self, area: Polygon) -> List[LineString]:
        """Encontra bordas da área que fazem interface com ruas"""
        bordas_com_rua = []
        
        try:
            # Converter perímetro em segmentos
            coords = list(area.exterior.coords)
            
            for i in range(len(coords) - 1):
                segmento = LineString([coords[i], coords[i + 1]])
                
                # Verificar se o segmento está próximo de alguma rua
                tem_acesso = False
                for rua in self.ruas:
                    if segmento.distance(rua) < 5.0:  # Tolerância de 5 metros
                        tem_acesso = True
                        break
                
                if tem_acesso:
                    bordas_com_rua.append(segmento)
            
            return bordas_com_rua
            
        except Exception as e:
            print(f"Erro ao encontrar bordas com rua: {e}")
            return []
    
    def alocar_areas_comuns_estrategicamente(self):
        """
        MODIFICADO: Aloca áreas comuns de forma estratégica conforme critérios do usuário.
        """
        try:
            area_total = self.perimetro_original.area
            percentual_verde = self.parametros['percentual_area_verde']
            percentual_institucional = self.parametros['percentual_area_institucional']
            
            area_verde_necessaria = (percentual_verde / 100) * area_total
            area_institucional_necessaria = (percentual_institucional / 100) * area_total
            
            print(f"Área verde necessária: {area_verde_necessaria:.2f} m² ({percentual_verde}%)")
            print(f"Área institucional necessária: {area_institucional_necessaria:.2f} m² ({percentual_institucional}%)")
            
            # Encontrar áreas disponíveis para áreas comuns
            areas_disponiveis = self._encontrar_areas_para_areas_comuns()
            
            # NOVA FUNCIONALIDADE: Aplicar critério estratégico para áreas verdes
            criterio_area_verde = self.parametros.get('criterio_area_verde', 'Áreas Remanescentes')
            areas_verdes_estrategicas = self._aplicar_criterio_area_verde(areas_disponiveis, criterio_area_verde)
            
            # Alocar áreas verdes estrategicamente
            self.areas_verdes = self._alocar_areas_verdes_estrategicas(areas_verdes_estrategicas, area_verde_necessaria)
            
            # Alocar áreas institucionais (sempre próximas à entrada)
            self.areas_institucionais = self._alocar_areas_institucionais_estrategicas(areas_disponiveis, area_institucional_necessaria)
            
            area_verde_total = sum(area.area for area in self.areas_verdes)
            area_institucional_total = sum(area.area for area in self.areas_institucionais)
            
            print(f"Áreas verdes alocadas: {len(self.areas_verdes)} ({area_verde_total:.2f} m²)")
            print(f"Áreas institucionais alocadas: {len(self.areas_institucionais)} ({area_institucional_total:.2f} m²)")
            
        except Exception as e:
            print(f"Erro na alocação de áreas comuns: {e}")
            self.areas_verdes = []
            self.areas_institucionais = []
    
    def _aplicar_criterio_area_verde(self, areas_disponiveis: List[Polygon], criterio: str) -> List[Polygon]:
        """
        NOVA FUNCIONALIDADE: Aplica critério estratégico para localização de áreas verdes.
        """
        try:
            if criterio == "Agrupar em Área Central":
                return self._priorizar_areas_centrais(areas_disponiveis)
            elif criterio == "Utilizar Áreas de Maior Declividade":
                return self._priorizar_areas_alta_declividade(areas_disponiveis)
            elif criterio == "Posicionar na Entrada do Loteamento":
                return self._priorizar_areas_entrada(areas_disponiveis)
            else:  # "Áreas Remanescentes"
                return areas_disponiveis
                
        except Exception as e:
            print(f"Erro ao aplicar critério de área verde: {e}")
            return areas_disponiveis
    
    def _priorizar_areas_centrais(self, areas_disponiveis: List[Polygon]) -> List[Polygon]:
        """
        Prioriza áreas próximas ao centro do loteamento.
        """
        try:
            centroide_loteamento = self.perimetro_original.centroid
            
            # Calcular distância de cada área ao centro
            areas_com_distancia = []
            for area in areas_disponiveis:
                distancia = area.centroid.distance(centroide_loteamento)
                areas_com_distancia.append((area, distancia))
            
            # Ordenar por distância (mais próximas primeiro)
            areas_com_distancia.sort(key=lambda x: x[1])
            
            return [area for area, _ in areas_com_distancia]
            
        except Exception as e:
            print(f"Erro ao priorizar áreas centrais: {e}")
            return areas_disponiveis
    
    def _priorizar_areas_alta_declividade(self, areas_disponiveis: List[Polygon]) -> List[Polygon]:
        """
        Prioriza áreas com maior declividade (se dados topográficos disponíveis).
        """
        try:
            if not self.topografia_map or not self.topografia_map.get('areas_alta_declividade'):
                # Se não há dados topográficos, usar critério padrão
                return areas_disponiveis
            
            areas_alta_declividade = self.topografia_map['areas_alta_declividade']
            
            # Calcular pontuação de declividade para cada área
            areas_com_pontuacao = []
            for area in areas_disponiveis:
                pontuacao_declividade = 0
                for ponto_alto in areas_alta_declividade:
                    if area.contains(ponto_alto) or area.distance(ponto_alto) < 20:
                        pontuacao_declividade += 1
                
                areas_com_pontuacao.append((area, pontuacao_declividade))
            
            # Ordenar por pontuação de declividade (maior primeiro)
            areas_com_pontuacao.sort(key=lambda x: x[1], reverse=True)
            
            return [area for area, _ in areas_com_pontuacao]
            
        except Exception as e:
            print(f"Erro ao priorizar áreas de alta declividade: {e}")
            return areas_disponiveis
    
    def _priorizar_areas_entrada(self, areas_disponiveis: List[Polygon]) -> List[Polygon]:
        """
        Prioriza áreas próximas à entrada do loteamento.
        """
        try:
            # Identificar pontos de entrada (pontos da borda mais próximos de ruas externas)
            pontos_entrada = self._identificar_pontos_entrada()
            
            if not pontos_entrada:
                return areas_disponiveis
            
            # Calcular distância de cada área aos pontos de entrada
            areas_com_distancia = []
            for area in areas_disponiveis:
                distancia_minima = min([area.centroid.distance(Point(ponto)) for ponto in pontos_entrada])
                areas_com_distancia.append((area, distancia_minima))
            
            # Ordenar por distância (mais próximas primeiro)
            areas_com_distancia.sort(key=lambda x: x[1])
            
            return [area for area, _ in areas_com_distancia]
            
        except Exception as e:
            print(f"Erro ao priorizar áreas de entrada: {e}")
            return areas_disponiveis
    
    def _identificar_pontos_entrada(self) -> List[Tuple[float, float]]:
        """
        Identifica pontos de entrada do loteamento.
        """
        try:
            # Simplificação: usar os pontos da borda do perímetro original
            # Em uma implementação mais sofisticada, isso poderia analisar conexões com vias externas
            coords = list(self.perimetro_original.exterior.coords)
            
            # Selecionar alguns pontos estratégicos da borda
            num_pontos = len(coords)
            pontos_entrada = []
            
            # Pegar pontos em intervalos regulares
            for i in range(0, num_pontos - 1, max(1, num_pontos // 4)):
                pontos_entrada.append(coords[i])
            
            return pontos_entrada
            
        except Exception as e:
            print(f"Erro ao identificar pontos de entrada: {e}")
            return []
    
    def _alocar_areas_verdes_estrategicas(self, areas_priorizadas: List[Polygon], area_necessaria: float) -> List[Polygon]:
        """
        Aloca áreas verdes seguindo a priorização estratégica.
        """
        areas_verdes = []
        area_alocada = 0
        
        try:
            for area in areas_priorizadas:
                if area_alocada >= area_necessaria:
                    break
                
                # Verificar se a área não foi usada para áreas institucionais
                if area not in self.areas_institucionais:
                    areas_verdes.append(area)
                    area_alocada += area.area
            
            return areas_verdes
            
        except Exception as e:
            print(f"Erro ao alocar áreas verdes estratégicas: {e}")
            return []
    
    def _alocar_areas_institucionais_estrategicas(self, areas_disponiveis: List[Polygon], area_necessaria: float) -> List[Polygon]:
        """
        Aloca áreas institucionais preferencialmente próximas à entrada.
        """
        try:
            # Sempre priorizar áreas próximas à entrada para áreas institucionais
            areas_priorizadas = self._priorizar_areas_entrada(areas_disponiveis)
            
            areas_institucionais = []
            area_alocada = 0
            
            for area in areas_priorizadas:
                if area_alocada >= area_necessaria:
                    break
                
                # Verificar se a área não foi usada para áreas verdes
                if area not in self.areas_verdes:
                    areas_institucionais.append(area)
                    area_alocada += area.area
            
            return areas_institucionais
            
        except Exception as e:
            print(f"Erro ao alocar áreas institucionais estratégicas: {e}")
            return []
    
    def _encontrar_areas_para_areas_comuns(self) -> List[Polygon]:
        """Encontra áreas disponíveis para áreas comuns"""
        areas_disponiveis = []
        
        try:
            # Área total disponível
            area_total = self.perimetro_internalizado
            
            # Subtrair ruas
            if self.ruas:
                ruas_unidas = unary_union(self.ruas)
                area_total = area_total.difference(ruas_unidas)
            
            # Subtrair lotes
            if self.lotes:
                lotes_unidos = unary_union(self.lotes)
                area_restante = area_total.difference(lotes_unidos)
                
                if isinstance(area_restante, Polygon):
                    areas_disponiveis.append(area_restante)
                elif isinstance(area_restante, MultiPolygon):
                    areas_disponiveis.extend([geom for geom in area_restante.geoms if isinstance(geom, Polygon)])
            
            # Filtrar áreas muito pequenas
            area_minima = self.parametros['area_minima_lote'] * 0.5
            areas_disponiveis = [area for area in areas_disponiveis if area.area >= area_minima]
            
            return areas_disponiveis
            
        except Exception as e:
            print(f"Erro ao encontrar áreas para áreas comuns: {e}")
            return []
    
    def _alocar_areas_verdes(self, areas_disponiveis: List[Polygon], area_necessaria: float) -> List[Polygon]:
        """Aloca áreas verdes"""
        areas_verdes = []
        area_alocada = 0
        
        # Ordenar áreas por tamanho (maiores primeiro)
        areas_ordenadas = sorted(areas_disponiveis, key=lambda x: x.area, reverse=True)
        
        for area in areas_ordenadas:
            if area_alocada >= area_necessaria:
                break
            
            areas_verdes.append(area)
            area_alocada += area.area
        
        return areas_verdes
    
    def _alocar_areas_institucionais(self, areas_disponiveis: List[Polygon], area_necessaria: float) -> List[Polygon]:
        """Aloca áreas institucionais"""
        areas_institucionais = []
        
        # Para áreas institucionais, usar áreas menores que não foram usadas para verde
        areas_usadas_verde = set(id(area) for area in self.areas_verdes)
        areas_restantes = [area for area in areas_disponiveis if id(area) not in areas_usadas_verde]
        
        area_alocada = 0
        for area in areas_restantes:
            if area_alocada >= area_necessaria:
                break
            
            areas_institucionais.append(area)
            area_alocada += area.area
        
        return areas_institucionais
    
    def calcular_estatisticas_detalhadas(self) -> Dict[str, float]:
        """Calcula estatísticas detalhadas do loteamento"""
        try:
            area_total = self.perimetro_original.area
            num_lotes = len(self.lotes)
            
            area_lotes = sum(lote.area for lote in self.lotes)
            area_ruas = sum(rua.area for rua in self.ruas)
            area_calcadas = sum(calcada.area for calcada in self.calcadas)
            area_verde = sum(area.area for area in self.areas_verdes)
            area_institucional = sum(area.area for area in self.areas_institucionais)
            
            return {
                'area_total': area_total,
                'num_lotes': num_lotes,
                'area_lotes': area_lotes,
                'area_ruas': area_ruas,
                'area_calcadas': area_calcadas,
                'area_verde': area_verde,
                'area_institucional': area_institucional
            }
            
        except Exception as e:
            print(f"Erro ao calcular estatísticas: {e}")
            return {
                'area_total': 0,
                'num_lotes': 0,
                'area_lotes': 0,
                'area_ruas': 0,
                'area_calcadas': 0,
                'area_verde': 0,
                'area_institucional': 0
            }
    
    def exportar_dxf_ultra_avancado(self, arquivo_saida: str):
        """
        MODIFICADO: Exporta o resultado em formato DXF com organização ultra-avançada e camadas detalhadas.
        """
        try:
            doc = ezdxf.new('R2010')
            msp = doc.modelspace()
            
            # NOVA FUNCIONALIDADE: Criar layers organizados com mais detalhes
            layers = {
                'PERIMETRO': {'color': 1, 'linetype': 'CONTINUOUS'},     # Vermelho
                'RUAS_PRINCIPAIS': {'color': 2, 'linetype': 'CONTINUOUS'}, # Amarelo
                'RUAS_SECUNDARIAS': {'color': 12, 'linetype': 'CONTINUOUS'}, # Amarelo claro
                'RUAS': {'color': 2, 'linetype': 'CONTINUOUS'},          # Amarelo (fallback)
                'CALCADAS': {'color': 8, 'linetype': 'CONTINUOUS'},      # Cinza
                'QUADRAS': {'color': 3, 'linetype': 'DASHED'},           # Verde
                'LOTES': {'color': 4, 'linetype': 'CONTINUOUS'},         # Ciano
                'LOTES_ESQUINA': {'color': 14, 'linetype': 'CONTINUOUS'}, # Ciano claro
                'LOTES_ATIPICOS': {'color': 5, 'linetype': 'DASHED'},    # Azul tracejado
                'AREA_VERDE': {'color': 3, 'linetype': 'CONTINUOUS'},    # Verde
                'AREA_INST': {'color': 6, 'linetype': 'CONTINUOUS'},     # Magenta
                'MALHA_VIARIA': {'color': 7, 'linetype': 'CENTER'},      # Branco
                'TOPOGRAFIA': {'color': 9, 'linetype': 'DOT'}            # Cinza pontilhado
            }
            
            # Criar layers
            for layer_name, props in layers.items():
                layer = doc.layers.new(layer_name)
                layer.color = props['color']
                layer.linetype = props['linetype']
            
            # Adicionar perímetro original
            if self.perimetro_original:
                coords = list(self.perimetro_original.exterior.coords)
                msp.add_lwpolyline(coords, dxfattribs={'layer': 'PERIMETRO'})
            
            # Adicionar malha viária
            for linha in self.malha_viaria:
                coords = list(linha.coords)
                msp.add_lwpolyline(coords, dxfattribs={'layer': 'MALHA_VIARIA'})
            
            # NOVA FUNCIONALIDADE: Classificar e adicionar ruas por hierarquia
            self._classificar_ruas_por_hierarquia()
            
            # Adicionar ruas principais
            for rua in self.ruas_principais:
                coords = list(rua.exterior.coords)
                msp.add_lwpolyline(coords, dxfattribs={'layer': 'RUAS_PRINCIPAIS'})
            
            # Adicionar ruas secundárias
            for rua in self.ruas_secundarias:
                coords = list(rua.exterior.coords)
                msp.add_lwpolyline(coords, dxfattribs={'layer': 'RUAS_SECUNDARIAS'})
            
            # Adicionar ruas (fallback para ruas não classificadas)
            for rua in self.ruas:
                if rua not in self.ruas_principais and rua not in self.ruas_secundarias:
                    coords = list(rua.exterior.coords)
                    msp.add_lwpolyline(coords, dxfattribs={'layer': 'RUAS'})
            
            # Adicionar calçadas
            for calcada in self.calcadas:
                coords = list(calcada.exterior.coords)
                msp.add_lwpolyline(coords, dxfattribs={'layer': 'CALCADAS'})
            
            # Adicionar quadras
            for quadra in self.quadras:
                coords = list(quadra.exterior.coords)
                msp.add_lwpolyline(coords, dxfattribs={'layer': 'QUADRAS'})
            
            # NOVA FUNCIONALIDADE: Adicionar lotes por categoria
            # Lotes de esquina
            for lote in self.lotes_esquina:
                coords = list(lote.exterior.coords)
                msp.add_lwpolyline(coords, dxfattribs={'layer': 'LOTES_ESQUINA'})
            
            # Lotes atípicos
            for lote in self.lotes_atipicos:
                coords = list(lote.exterior.coords)
                msp.add_lwpolyline(coords, dxfattribs={'layer': 'LOTES_ATIPICOS'})
            
            # Lotes normais (excluindo esquina e atípicos)
            for lote in self.lotes:
                if lote not in self.lotes_esquina and lote not in self.lotes_atipicos:
                    coords = list(lote.exterior.coords)
                    msp.add_lwpolyline(coords, dxfattribs={'layer': 'LOTES'})
            
            # Adicionar áreas verdes
            for area in self.areas_verdes:
                coords = list(area.exterior.coords)
                msp.add_lwpolyline(coords, dxfattribs={'layer': 'AREA_VERDE'})
            
            # Adicionar áreas institucionais
            for area in self.areas_institucionais:
                coords = list(area.exterior.coords)
                msp.add_lwpolyline(coords, dxfattribs={'layer': 'AREA_INST'})
            
            # NOVA FUNCIONALIDADE: Adicionar dados topográficos se disponíveis
            if self.topografia_map and self.topografia_map.get('curvas_nivel'):
                for curva in self.topografia_map['curvas_nivel']:
                    coords = list(curva.coords)
                    msp.add_lwpolyline(coords, dxfattribs={'layer': 'TOPOGRAFIA'})
            
            # Salvar arquivo
            doc.saveas(arquivo_saida)
            print(f"Arquivo DXF ultra-avançado salvo: {arquivo_saida}")
            
            # Imprimir estatísticas das camadas
            self._imprimir_estatisticas_camadas()
            
        except Exception as e:
            print(f"Erro ao exportar DXF ultra-avançado: {e}")
    
    def _classificar_ruas_por_hierarquia(self):
        """
        NOVA FUNCIONALIDADE: Classifica ruas em principais e secundárias.
        """
        try:
            if not self.ruas:
                return
            
            # Limpar listas
            self.ruas_principais = []
            self.ruas_secundarias = []
            
            # Critério: ruas maiores são principais, menores são secundárias
            largura_via_principal = self.parametros.get('largura_via_principal', 12.0)
            largura_via_secundaria = self.parametros.get('largura_via_secundaria', 8.0)
            
            # Calcular área média das ruas para classificação
            areas_ruas = [rua.area for rua in self.ruas]
            if areas_ruas:
                area_media = sum(areas_ruas) / len(areas_ruas)
                
                for rua in self.ruas:
                    if rua.area > area_media * 1.2:  # 20% maior que a média
                        self.ruas_principais.append(rua)
                    else:
                        self.ruas_secundarias.append(rua)
            else:
                # Se não conseguiu classificar, todas são secundárias
                self.ruas_secundarias = self.ruas.copy()
            
            print(f"Classificação de ruas: {len(self.ruas_principais)} principais, {len(self.ruas_secundarias)} secundárias")
            
        except Exception as e:
            print(f"Erro ao classificar ruas por hierarquia: {e}")
            # Fallback: todas as ruas são secundárias
            self.ruas_principais = []
            self.ruas_secundarias = self.ruas.copy()
    
    def _imprimir_estatisticas_camadas(self):
        """
        NOVA FUNCIONALIDADE: Imprime estatísticas detalhadas das camadas exportadas.
        """
        try:
            print("\n=== ESTATÍSTICAS DAS CAMADAS EXPORTADAS ===")
            print(f"Perímetro: 1 elemento")
            print(f"Malha viária: {len(self.malha_viaria)} linhas")
            print(f"Ruas principais: {len(self.ruas_principais)} elementos")
            print(f"Ruas secundárias: {len(self.ruas_secundarias)} elementos")
            print(f"Calçadas: {len(self.calcadas)} elementos")
            print(f"Quadras: {len(self.quadras)} elementos")
            print(f"Lotes normais: {len(self.lotes) - len(self.lotes_esquina) - len(self.lotes_atipicos)} elementos")
            print(f"Lotes de esquina: {len(self.lotes_esquina)} elementos")
            print(f"Lotes atípicos: {len(self.lotes_atipicos)} elementos")
            print(f"Áreas verdes: {len(self.areas_verdes)} elementos")
            print(f"Áreas institucionais: {len(self.areas_institucionais)} elementos")
            
            if self.topografia_map and self.topografia_map.get('curvas_nivel'):
                print(f"Curvas de nível: {len(self.topografia_map['curvas_nivel'])} elementos")
            
            print("=" * 50)
            
        except Exception as e:
            print(f"Erro ao imprimir estatísticas das camadas: {e}")

