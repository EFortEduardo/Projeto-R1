#!/usr/bin/env python3.11
"""
Teste básico das funcionalidades do aplicativo de loteamento urbano melhorado.
"""

import sys
import os
sys.path.append('src')

from shapely.geometry import Polygon
from loteamento_processor_ultra_avancado import LoteamentoProcessorUltraAvancado

def criar_perimetro_teste():
    """Cria um perímetro de teste simples (retângulo)."""
    return Polygon([
        (0, 0),
        (100, 0),
        (100, 80),
        (0, 80),
        (0, 0)
    ])

def teste_basico():
    """Teste básico das funcionalidades principais."""
    print("=== TESTE BÁSICO DO APLICATIVO MELHORADO ===")
    
    # Parâmetros de teste com as novas funcionalidades
    parametros = {
        'largura_rua': 8.0,
        'largura_calcada': 2.0,
        'area_minima_lote': 200.0,
        'testada_minima_lote': 10.0,
        'testada_preferencial_lote': 15.0,
        'profundidade_padrao_lote': 20.0,
        'profundidade_max_quadra': 80.0,
        'percentual_area_verde': 15.0,
        'percentual_area_institucional': 5.0,
        
        # NOVOS PARÂMETROS DO PLANO 2.0
        'arquivo_topografia': None,
        'inclinacao_maxima_vias': 8.0,
        'inclinacao_maxima_lotes': 30.0,
        'largura_via_principal': 12.0,
        'largura_via_secundaria': 8.0,
        'permitir_cul_de_sacs': True,
        'raio_retorno_cul_de_sac': 12.0,
        'criterio_orientacao_arruamento': 'Eixo Principal do Terreno',
        'criterio_area_verde': 'Agrupar em Área Central',
        'tratamento_lotes_esquina': 'Chanfrar',
        'distancia_chanfro': 3.0,
        'raio_curvatura': 5.0
    }
    
    # Criar perímetro de teste
    perimetro = criar_perimetro_teste()
    print(f"Perímetro de teste criado: {perimetro.area} m²")
    
    # Inicializar processador
    processor = LoteamentoProcessorUltraAvancado(parametros)
    
    # Definir perímetro diretamente (para teste)
    processor.perimetro_original = perimetro
    
    try:
        # Executar processamento interno
        print("\nIniciando processamento...")
        
        # Testar componentes individuais
        processor.internalizar_perimetro_com_calcadas()
        print("✅ Internalização do perímetro OK")
        
        processor.criar_sistema_viario_criativo()
        print("✅ Sistema viário OK")
        
        processor.formar_quadras_com_refinamento()
        print("✅ Formação de quadras OK")
        
        processor.subdividir_quadras_ultra_otimizado()
        print("✅ Subdivisão de lotes OK")
        
        processor.alocar_areas_comuns_estrategicamente()
        print("✅ Alocação de áreas comuns OK")
        
        # Verificar resultados
        stats = processor.calcular_estatisticas_detalhadas()
        print(f"\n=== ESTATÍSTICAS ===")
        print(f"Área total: {stats['area_total']:.2f} m²")
        print(f"Número de lotes: {stats['num_lotes']}")
        print(f"Área de lotes: {stats['area_lotes']:.2f} m²")
        print(f"Área de ruas: {stats['area_ruas']:.2f} m²")
        print(f"Área verde: {stats['area_verde']:.2f} m²")
        print(f"Área institucional: {stats['area_institucional']:.2f} m²")
        
        # Testar exportação DXF
        arquivo_teste = "/home/ubuntu/teste_loteamento.dxf"
        processor.exportar_dxf_ultra_avancado(arquivo_teste)
        
        if os.path.exists(arquivo_teste):
            print(f"✅ Arquivo DXF exportado: {arquivo_teste}")
            print(f"Tamanho do arquivo: {os.path.getsize(arquivo_teste)} bytes")
        else:
            print("❌ Falha na exportação DXF")
        
        return True
            
    except Exception as e:
        print(f"❌ Erro durante o teste: {e}")
        import traceback
        traceback.print_exc()
        return False

def teste_novas_funcionalidades():
    """Teste específico das novas funcionalidades."""
    print("\n=== TESTE DAS NOVAS FUNCIONALIDADES ===")
    
    # Teste das hipóteses de malha viária
    parametros_teste = {
        'largura_rua': 8.0,
        'largura_calcada': 2.0,
        'profundidade_max_quadra': 80.0,
        'area_minima_lote': 200.0,
        'testada_minima_lote': 10.0,
        'criterio_orientacao_arruamento': 'Orientação Solar (Norte-Sul / Leste-Oeste)'
    }
    
    processor = LoteamentoProcessorUltraAvancado(parametros_teste)
    perimetro = criar_perimetro_teste()
    
    # Definir perímetro e internalizar
    processor.perimetro_original = perimetro
    processor.internalizar_perimetro_com_calcadas()
    
    try:
        # Testar geração de hipóteses
        print("Testando geração de hipóteses de malha viária...")
        
        hipotese_a = processor._gerar_hipotese_eixo_principal()
        hipotese_b = processor._gerar_hipotese_maior_segmento()
        hipotese_c = processor._gerar_hipotese_orientacao_solar()
        
        print(f"✅ Hipótese A (Eixo Principal): {len(hipotese_a)} linhas")
        print(f"✅ Hipótese B (Maior Segmento): {len(hipotese_b)} linhas")
        print(f"✅ Hipótese C (Orientação Solar): {len(hipotese_c)} linhas")
        
        # Testar pontuação
        pontuacao_a = processor._calcular_pontuacao(hipotese_a)
        pontuacao_b = processor._calcular_pontuacao(hipotese_b)
        pontuacao_c = processor._calcular_pontuacao(hipotese_c)
        
        print(f"✅ Pontuação A: {pontuacao_a:.2f}")
        print(f"✅ Pontuação B: {pontuacao_b:.2f}")
        print(f"✅ Pontuação C: {pontuacao_c:.2f}")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro no teste das novas funcionalidades: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("Iniciando testes do aplicativo de loteamento urbano melhorado...")
    
    # Executar testes
    teste1 = teste_basico()
    teste2 = teste_novas_funcionalidades()
    
    if teste1 and teste2:
        print("\n🎉 TODOS OS TESTES PASSARAM! 🎉")
        print("O aplicativo melhorado está funcionando corretamente.")
    else:
        print("\n❌ ALGUNS TESTES FALHARAM")
        print("Verifique os erros acima para mais detalhes.")

